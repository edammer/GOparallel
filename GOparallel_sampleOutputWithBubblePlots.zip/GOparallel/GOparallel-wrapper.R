rootdir="/path/to/working/directory/"
setwd(rootdir)

load("MEGA488_forORA.RData")
cleanDat<-cleanDatMEGA        # log2 abundance, corrected
numericMeta<-numericMetaMEGA  # sample traits
net<-netMEGA                  # list from WGCNA::blockwiseModules() function


######################## EDIT THESE VARIABLES (USER PARAMETERS SET IN GLOBAL ENVIRONMENT) ############################################
#inputFile <- "ENDO_MG_TWO_WAY_LIST_NTS_v02b_forGOelite.csv"                                            #Sample File 1 - has full human background
#inputFile <- "ModuleAssignments_Jingting32TH_BOOTaspRegr_power8_MergeHeight0.07_PAMstageTRUE_ds2.csv"  #Sample File 2 - WGCNA kME table for (Dai, et al, 2019)
            #INPUT CSV FILE - in the filePath folder.
            #Can be formatted as Kme table from WGCNA pipeline, or
            #can be a CSV of columns, one symbol or UniqueID (Symbol|...) list per column, with the LIST NAMEs in row 1
            #in this case, the longest list is used as background or the "universe" for the FET contingencies
            #  For simple columnwise list input, DON'T FORGET TO PUT THE APPROPRIATE BACKGROUND LIST IN, OR RESULTS WILL BE UNRELIABLE.

filePath <- rootdir   #gsub("//","/",outputfigs)
            #Folder that (may) contain the input file specified above, and which will contain the outFilename project Folder.

outFilename <- "MEGATMT"
            #SUBFOLDER WITH THIS NAME WILL BE CREATED, and .PDF + .csv file using the same name will be created within this folder.

outputGOeliteInputs=FALSE
            #If TRUE, GO Elite background file and module or list-specific input files will be created in the outFilename subfolder.

maxBarsPerOntology=5
            #Ontologies per ontology type, used for generating the PDF report; does not limit tabled output

GMTdatabaseFile="Human_GO_AllPathways_noPFOCR_with_GO_iea_March_01_2025_symbol.gmt"   # e.g. "Human_GO_AllPathways_with_GO_iea_June_01_2022_symbol.gmt"
                                              # Current month release will be downloaded if file does not exist.
					      # **Specify a nonexistent file to always download the current database to this folder.**
					      # Database .GMT file will be saved to the specified folder with its original date-specific name.
            #path/to/filename of ontology database for the appropriate species (no conversion is performed)
            #BaderLab website links to their current monthly update of ontologies for Human, Mouse, and Rat, minimally
            #http://download.baderlab.org/EM_Genesets/current_release/
            #For more information, see documentation:  http://baderlab.org/GeneSets

panelDimensions=c(3,2)    #dimensions of the individual parblots within a page of the main barplot PDF output
pageDimensions=c(8.5,11)  #main barplot PDF output page dimensions, in inches

color=c("darkseagreen3","lightsteelblue1","lightpink4","goldenrod","darkorange","gold")
            #colors respectively for ontology Types:
            #"Biological Process","Molecular Function","Cellular Component","Reactome","WikiPathways","MSig.C2"
            #must be valid R colors

modulesInMemory=TRUE
            #uses cleanDat, net, and kMEdat from WGCNA systems biology pipeline already run, and these variables must be in memory
            #inputFile will be ignored
ANOVAgroups=FALSE
            #if true, modulesInMemory ignored. Volcano pipeline code should already have been run!
            #inputFile will be ignored

############ MUST HAVE AT LEAST 2 THREADS ENABLED TO RUN ############################################################################

parallelThreads=30

removeRedundantGOterms="kappa"
            # if TRUE, ontologyIndex parent terms are kept as a minimal term set (less redundancy for 3 main ontology types);
            # if "kappa", graph-based clustering redundancy removal is performed in parallel, reducing similar ontologies
            #   within each of the 6 types to keep the one best enrichment scorer for the cluster of terms with kappa <0.30.
            # if FALSE, no redundancy removal is performed.

GO.OBOfile<-"go.obo"
            #only used and needed if above flag to remove redundant GO terms is TRUE.
	    #Download from http://current.geneontology.org/ontology/go.obo will commence into the specified folder if the specified filename does not exist.
            #Does not appear to be species specific, stores all GO term relations and is periodically updated.

cocluster=TRUE
            #If TRUE, output PDF of signed Zscore coclustering on GO:cellular component terms (useful for WGCNA modules)

bubble=TRUE
            #if TRUE, GSEA style bubble plots for each input list's enriched ontologies for each of the 6 ontology types will be output to PDF

######################## END OF PARAMETER VARIABLES ###################################################################################

source("GOparallel-FET.R")
GOparallel()  # parameters are set in global environment as above; if not set, the function falls back to defaults and looks for all inputs available.
              # priority is given to modulesInMemory